<?php
require 'vendor/autoload.php';

use Phpml\ModelManager;

function predict_with_model($json_model_file, $example_new_data) {
    // Read the JSON model file
    $json_content = file_get_contents($json_model_file);

    // Decode the JSON content
    $model_data = json_decode($json_content, true);

    // Retrieve the coefficients and intercept
    $coefficients = $model_data['coefficients'];
    $intercept = $model_data['intercept'];

    // Perform prediction on the example new data
    $predicted_price = 0;
    for ($i = 0; $i < count($coefficients); $i++) {
        $predicted_price += $coefficients[$i] * $example_new_data[$i];
    }
    $predicted_price += $intercept;

    return $predicted_price;
}




?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PREDIKSI HARGA SOLANA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

    <style>
      /* Custom CSS for the modal */
      .modal-content {
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
      }

      .modal-header {
        background-color: #007bff;
        color: #fff;
        border-radius: 10px 10px 0 0;
      }

      .modal-body {
        padding: 20px;
      }

      .modal-footer {
        border-radius: 0 0 10px 10px;
      }

      /* Custom CSS for the prediction result section */
      #predictionResult {
        margin-top: 20px;
      }

      #predictionResult h6 {
        color: #007bff;
        font-size: 18px;
        margin-bottom: 10px;
      }

      #predictionResult p {
        margin: 5px 0;
      }

      /* Custom CSS for the "Submit" button */
      .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
      }

      .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
      }

      .btn-primary:focus {
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.5);
      }
    </style>

  </head>
  <body>
    <div class="modal position-static d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Prediksi Harga SOLANA USD</h5>
          </div>
          <div class="modal-body">
            <form id="predictionForm" method="post" action="">
              <div class="mb-3">
                <label for="pembukaan" class="form-label">Masukan Harga Pembukaan</label>
                <input type="text" name="pembukaan" class="form-control" id="pembukaan" aria-describedby="emailHelp">
              </div>
              <div class="mb-3">
                <label for="tinggi" class="form-label">Masukan Harga Tertinggi</label>
                <input type="text" name="tinggi" class="form-control" id="tinggi" aria-describedby="emailHelp">
              </div>
              <div class="mb-3">
                <label for="terendah" class="form-label">Masukan Harga Terendah</label>
                <input type="text" name="terendah" class="form-control" id="terendah" aria-describedby="emailHelp">
              </div>
              <button type="submit" name="submit" class="btn btn-primary" onclick="predictPrice()">Submit</button>
            </form>
            <br>
            <div>
              <h6><?php
if(isset($_POST['submit'])){
$buka = $_POST['pembukaan'];
$tinggi = $_POST['tinggi'];
$rendah = $_POST['terendah'];

if (!empty($buka) && !empty($tinggi) && !empty($rendah)) {
    
$feature_columns = [$buka, $tinggi, $rendah];
$json_model_file = 'linear_regression_model.json';
$predicted_price = predict_with_model($json_model_file, $feature_columns);
echo "Prediksi Harga SOLANA USD:  " . $predicted_price . "\n";

}
else {
    echo'Ada  Bagian Yang Kosong ';
}
  }
else{

}
    ?>
    </h6>
            </div>
          </div>
          <div class="modal-footer">
          </div>
        
        </div>
      </div>
    </div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="custom.js"></script>
  </body>
</html>
