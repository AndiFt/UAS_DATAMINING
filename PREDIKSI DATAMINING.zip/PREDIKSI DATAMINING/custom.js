function predictPrice() {
  // Ambil nilai dari input form
  const pembukaan = parseFloat(document.getElementById('pembukaan').value);
  const tertinggi = parseFloat(document.getElementById('tinggi').value);
  const terendah = parseFloat(document.getElementById('terendah').value);

  // Lakukan prediksi atau validasi input di sini (contoh sederhana: pastikan semua input diisi)
  if (isNaN(pembukaan) || isNaN(tertinggi) || isNaN(terendah)) {
    alert("Harap isi semua field dengan angka.");
    return;
  }

  // Tampilkan hasil prediksi pada elemen "predictionResult"
  document.getElementById('predictedPembukaan').textContent = pembukaan;
  document.getElementById('predictedTertinggi').textContent = tertinggi;
  document.getElementById('predictedTerendah').textContent = terendah;

  // Tampilkan elemen "predictionResult" dan sembunyikan form setelah prediksi selesai
  document.getElementById('predictionResult').classList.remove('d-none');
  document.getElementById('predictionForm').classList.add('d-none');

function showForm() {
// Tampilkan kembali "formSection" dan sembunyikan "resultSection"
  document.getElementById('formSection').classList.remove('d-none');
  document.getElementById('resultSection').classList.add('d-none');
// Reset input form
  document.getElementById('pembukaan').value = '';
  document.getElementById('tinggi').value = '';
  document.getElementById('terendah').value = '';
  
 }
}
